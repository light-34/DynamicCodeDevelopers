﻿namespace SchoolMangementSystem
{
    internal class Experiment : IProof
    {
        public void Prove()
        {
            System.Console.WriteLine("Student prove a question");
        }
    }
}